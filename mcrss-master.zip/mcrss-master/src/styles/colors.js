export const screenBackground = '#F6F6F6';
export const headerBackground = '#1B7744';
